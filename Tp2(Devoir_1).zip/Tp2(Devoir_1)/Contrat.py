from Client import Client


class Contrat:
  def __init__(self, numero: float, date:str, client:Client, montantContrat: float):
    self.__numero = numero
    self.__date = date
    self.__client = client
    self.__montantContrat = montantContrat
    self.__interventions = []
    self.__nbIntervention = 0

  def montant(self):
    return self.__montantContrat

  def ecart(self):
    totalIntervention = 0
    for intervention in self.interventions:
      totalIntervention += intervention.fraisKm(0) + intervention.fraisMo()
    return self.__montantContrat - totalIntervention