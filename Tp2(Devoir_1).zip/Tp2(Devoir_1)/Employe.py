class Employe:
    def __init__(self, numero: int, nom: str, qualification: str, dateEmbauche: str):
        self.__numero = numero
        self.__nom = nom
        self.__qualification = qualification
        self.__dateEmbauche = dateEmbauche
    
    def coutHoraire(self) -> float:
        if self.__qualification == "a":
            cout_qualif = 20.0
        elif self.__qualification == "b":
            cout_qualif = 25.0
        else:
            cout_qualif = 30.0
        
        anciennete = self.getAncienete(self.__dateEmbauche)
        
        if anciennete < 5:
            cout_anciennete = 1.0
        elif anciennete < 10:
            cout_anciennete = 1.1
        else:
            cout_anciennete = 1.2
        
        return cout_qualif * cout_anciennete
    
    def getAncienete(self, date: str) -> int:
        annee_embauche = int(self.dateEmbauche[-4:])
        annee_courante = int(date[-4:])
        
        return annee_courante - annee_embauche
    
    def getNumero(self) -> int:
        return self.__numero
    
    def getNom(self) -> str:
        return self.__nom
    
    def getQualification(self) -> str:
        return self.__qualification
    
    def getDateEmbauche(self) -> str:
        return self.__dateEmbauche