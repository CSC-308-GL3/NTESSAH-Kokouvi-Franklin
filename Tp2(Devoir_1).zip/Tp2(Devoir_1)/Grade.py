class Grade:
    def __init__(self, code: str, libelle: str, taux: float):
        self.__code = code
        self.__libelle = libelle
        self.__taux = taux
    
    def getCode(self) -> str:
        return self.__code
    
    def getLibelle(self) -> str:
        return self.__libelle
    
    def tauxHoraire(self) -> float:
        return self.__taux