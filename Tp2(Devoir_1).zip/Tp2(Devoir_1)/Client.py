class Client:
    def __init__(self, numero:float, nom:str, adresse:str, code_postale:str, ville:str, nb_km:float):
        self.__numero = numero
        self.__nom = nom
        self.__adresse = adresse
        self.__code_postale = code_postale
        self.__ville = ville
        self.__nb_km = nb_km
    
    def distance(self):
      
        return self.__nb_km