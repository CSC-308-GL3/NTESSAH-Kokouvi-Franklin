from Employe import Employe


class Intervention:
    def __init__(self, numero: int, date: str, duree: int, tarifKm: float, technicien: Employe):
        self.__numero = numero
        self.__date = date
        self.__duree = duree
        self.__tarifKm = tarifKm
        self.__technicien = technicien
    
    def fraisKm(self, dist: float) -> float:
        return dist * self.tarifKm
    
    def fraisMo(self) -> float:
        return self.technicien.taux_horaire * self.duree
        
    def affiche(self):
        print("Intervention numéro :", self.__numero)
        print("Date :", self.__date)
        print("Durée :", self.__duree, "heures")
        print("Frais kilométriques :", self.fraisKm(), "€")
        print("Frais de main-d'oeuvre :", self.fraisMo(), "€")
        print("Technicien :", self.__technicien.nom)
